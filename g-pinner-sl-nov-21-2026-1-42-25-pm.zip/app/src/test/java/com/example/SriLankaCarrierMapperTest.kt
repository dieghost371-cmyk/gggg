package com.example

import com.example.data.SriLankaCarrierMapper
import com.example.model.CellTowerReading
import com.example.model.SriLankaCarrier
import org.junit.Assert.assertEquals
import org.junit.Test

class SriLankaCarrierMapperTest {

    @Test
    fun mapsSriLankaMccMncAccurately() {
        assertEquals(SriLankaCarrier.MOBITEL, SriLankaCarrierMapper.mapMccMncToCarrier("413", "01"))
        assertEquals(SriLankaCarrier.DIALOG, SriLankaCarrierMapper.mapMccMncToCarrier("413", "02"))
        assertEquals(SriLankaCarrier.HUTCH, SriLankaCarrierMapper.mapMccMncToCarrier("413", "08"))
        assertEquals(SriLankaCarrier.HUTCH, SriLankaCarrierMapper.mapMccMncToCarrier("413", "03"))
        assertEquals(SriLankaCarrier.AIRTEL, SriLankaCarrierMapper.mapMccMncToCarrier("413", "05"))
        assertEquals(SriLankaCarrier.SLT, SriLankaCarrierMapper.mapMccMncToCarrier("413", "12"))
    }

    @Test
    fun aggregatesAndRanksStrongestCarrierFirst() {
        val readings = listOf(
            CellTowerReading(
                carrier = SriLankaCarrier.DIALOG,
                operatorName = "Dialog Axiata",
                mccMnc = "413-02",
                networkType = "4G LTE",
                dbm = -88,
                asu = 52,
                bars = 3,
                qualityPercent = 55,
                qualityLabel = "Good",
                isRegistered = true,
                cellId = "101",
                pciOrPsc = "PCI 1",
                tacOrLac = "TAC 1"
            ),
            CellTowerReading(
                carrier = SriLankaCarrier.HUTCH,
                operatorName = "Hutch (SL)",
                mccMnc = "413-08",
                networkType = "4G LTE",
                dbm = -72,
                asu = 68,
                bars = 5,
                qualityPercent = 80,
                qualityLabel = "Excellent",
                isRegistered = false,
                cellId = "202",
                pciOrPsc = "PCI 2",
                tacOrLac = "TAC 2"
            )
        )

        val ranked = SriLankaCarrierMapper.aggregateCarriers(readings)
        assertEquals(2, ranked.size)
        assertEquals(SriLankaCarrier.HUTCH, ranked.first().carrier)
        assertEquals(-72, ranked.first().bestDbm)
    }
}
