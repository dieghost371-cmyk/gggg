package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val GPinnerColorScheme = darkColorScheme(
    primary = SignalCyan,
    onPrimary = ObsidianBg,
    primaryContainer = Color(0xFF003B4D),
    onPrimaryContainer = SignalCyan,
    secondary = SignalEmerald,
    onSecondary = ObsidianBg,
    secondaryContainer = Color(0xFF003D22),
    onSecondaryContainer = SignalEmerald,
    tertiary = GhostViolet,
    onTertiary = Color.White,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = SlateSurface,
    onSurface = TextPrimary,
    surfaceVariant = SlateSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    surfaceContainerHigh = SlateSurfaceHigh,
    outline = SlateBorder,
    outlineVariant = SlateBorder,
    error = SignalCoral,
    onError = Color.White
)

private val GPinnerShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun GPinnerTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GPinnerColorScheme,
        typography = GPinnerTypography,
        shapes = GPinnerShapes,
        content = content
    )
}
