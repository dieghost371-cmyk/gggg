package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Obsidian RF Telemetry Palette
val ObsidianBg = Color(0xFF080C14)
val SlateSurface = Color(0xFF101726)
val SlateSurfaceElevated = Color(0xFF162033)
val SlateSurfaceHigh = Color(0xFF1D2942)
val SlateBorder = Color(0xFF263552)

// Accents
val SignalCyan = Color(0xFF00E5FF)
val SignalEmerald = Color(0xFF00E676)
val SignalAmber = Color(0xFFFFB300)
val SignalCoral = Color(0xFFFF5252)
val GhostViolet = Color(0xFF8B5CF6)

// Text Hierarchy
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Sri Lankan Carrier Brand Accents
val CarrierDialog = Color(0xFFE11D48)     // Dialog Axiata Crimson
val CarrierMobitel = Color(0xFF0EA5E9)    // SLT-Mobitel Electric Blue
val CarrierHutch = Color(0xFFF97316)      // Hutch / Etisalat Orange
val CarrierAirtel = Color(0xFFEF4444)     // Airtel Scarlet
val CarrierSlt = Color(0xFF14B8A6)        // SLT Fiber/4G Teal
val CarrierOther = Color(0xFF8B5CF6)      // Other / Test Tower
