package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.CellTower
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.MyLocation
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.SignalCellularAlt
import androidx.compose.material.icons.rounded.SimCard
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.model.CarrierSummary
import com.example.model.InsertedSimInfo
import com.example.model.LocationSnapshot
import com.example.model.ScanUiState
import com.example.model.SriLankaCarrier
import com.example.ui.ScannerViewModel
import com.example.ui.components.AnimatedSignalBars
import com.example.ui.components.SignalQualityPill
import com.example.ui.components.TacticalRadarVisualizer
import com.example.ui.components.signalStrengthColor
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCyan
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateSurface
import com.example.ui.theme.SlateSurfaceElevated
import com.example.ui.theme.SlateSurfaceHigh
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun ScannerScreen(
    viewModel: ScannerViewModel,
    contentPadding: PaddingValues
) {
    val hasLocationPermission by viewModel.hasLocationPermission.collectAsStateWithLifecycle()
    val scanState by viewModel.scanState.collectAsStateWithLifecycle()
    val insertedSims by viewModel.insertedSims.collectAsStateWithLifecycle()
    val locationSnapshot by viewModel.locationSnapshot.collectAsStateWithLifecycle()
    val isPreviewMode by viewModel.isPreviewMode.collectAsStateWithLifecycle()

    var showPinDialog by remember { mutableStateOf(false) }
    var pinLabelText by remember { mutableStateOf("") }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.onPermissionsResult()
    }

    val requestPermissionsAction = {
        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.READ_PHONE_STATE
            )
        )
    }

    val currentResults = scanState as? ScanUiState.Results
    val isScanning = scanState is ScanUiState.Scanning

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = contentPadding.calculateTopPadding() + 8.dp,
                bottom = contentPadding.calculateBottomPadding() + 24.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Atmospheric Hero Header Banner
            item {
                HeroBannerCard(
                    locationSnapshot = locationSnapshot,
                    insertedSims = insertedSims
                )
            }

            // 2. Preview Mode Warning Banner (Only when user manually enables preview)
            if (isPreviewMode) {
                item {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = SignalAmber.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, SignalAmber.copy(alpha = 0.55f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.WarningAmber,
                                contentDescription = "Preview mode warning",
                                tint = SignalAmber
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "LAB PREVIEW MODE ACTIVE",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = SignalAmber
                                )
                                Text(
                                    text = "Showing sample Sri Lanka tower data for emulator testing. Turn off for live device modem scan.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextPrimary
                                )
                            }
                        }
                    }
                }
            }

            // 3. Location Permission Card if not granted
            if (!hasLocationPermission && !isPreviewMode) {
                item {
                    PermissionPromptCard(onGrantClick = requestPermissionsAction)
                }
            }

            // 4. Tactical Radar & Primary Scan Button
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = SlateSurface),
                    border = BorderStroke(1.dp, SlateBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        TacticalRadarVisualizer(
                            isScanning = isScanning,
                            bestCarrier = currentResults?.bestCarrier,
                            rankedCarriers = currentResults?.rankedCarriers.orEmpty()
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        if (scanState is ScanUiState.Scanning) {
                            val scanning = scanState as ScanUiState.Scanning
                            Text(
                                text = scanning.statusMessage,
                                style = MaterialTheme.typography.labelMedium,
                                color = SignalCyan
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { scanning.progress },
                                modifier = Modifier
                                    .fillMaxWidth(0.8f)
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(50)),
                                color = SignalCyan,
                                trackColor = SlateSurfaceHigh
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                        }

                        Button(
                            onClick = {
                                if (!hasLocationPermission && !isPreviewMode) {
                                    requestPermissionsAction()
                                } else {
                                    viewModel.startScan()
                                }
                            },
                            enabled = !isScanning,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("scan_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SignalCyan,
                                contentColor = ObsidianBg,
                                disabledContainerColor = SignalCyan.copy(alpha = 0.4f)
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Radar,
                                contentDescription = null,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when {
                                    isScanning -> stringResource(R.string.scanning_label)
                                    !hasLocationPermission && !isPreviewMode -> stringResource(R.string.grant_permission)
                                    currentResults != null -> stringResource(R.string.rescan_button)
                                    else -> stringResource(R.string.scan_button)
                                },
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }

            // 5. Results Section: #1 Strongest SIM Hero Card
            if (currentResults != null) {
                item {
                    AnimatedVisibility(
                        visible = true,
                        enter = fadeIn(tween(350)) + slideInVertically(initialOffsetY = { it / 4 })
                    ) {
                        BestCarrierHeroCard(
                            best = currentResults.bestCarrier,
                            totalTowers = currentResults.totalTowersScanned,
                            hasSriLankaTowers = currentResults.hasSriLankaTowers,
                            onPinClick = {
                                pinLabelText = ""
                                showPinDialog = true
                            }
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "DETECTED NETWORK RANKING",
                            style = MaterialTheme.typography.labelLarge,
                            color = TextSecondary
                        )
                        Text(
                            text = "${currentResults.rankedCarriers.size} carriers • ${currentResults.totalTowersScanned} towers",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }
                }

                itemsIndexed(
                    items = currentResults.rankedCarriers,
                    key = { index, item -> "${item.carrier.name}_${item.mccMnc}_$index" }
                ) { index, summary ->
                    CarrierComparisonCard(
                        rank = index + 1,
                        summary = summary
                    )
                }
            }

            // 6. Honest No-Towers Diagnostic (for Emulators or Airplane Mode)
            if (scanState is ScanUiState.NoTowers) {
                val noTowers = scanState as ScanUiState.NoTowers
                item {
                    NoTowersDiagnosticCard(
                        reason = noTowers.reason,
                        operatorHint = noTowers.activeOperatorHint
                    )
                }
            }

            // 7. Lab Preview Toggle Footer (Explicitly off by default)
            item {
                LabPreviewToggleCard(
                    isPreviewMode = isPreviewMode,
                    onToggle = { viewModel.togglePreviewMode(it) }
                )
            }
        }
    }

    if (showPinDialog) {
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            containerColor = SlateSurfaceElevated,
            title = {
                Text(
                    text = "Pin Signal Location",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Save the strongest SIM at this spot to your offline history.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                    OutlinedTextField(
                        value = pinLabelText,
                        onValueChange = { pinLabelText = it },
                        label = { Text("Location name (e.g. Home, Pelgahathenna)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pin_label_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.saveCurrentPin(pinLabelText.ifBlank { "My Location" })
                        showPinDialog = false
                    },
                    modifier = Modifier.testTag("confirm_pin_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SignalEmerald,
                        contentColor = ObsidianBg
                    )
                ) {
                    Text("Save Pin")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPinDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun HeroBannerCard(
    locationSnapshot: LocationSnapshot,
    insertedSims: List<InsertedSimInfo>
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = SlateSurface),
        border = BorderStroke(1.dp, SlateBorder)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = R.drawable.img_srilanka_banner),
                contentDescription = "Sri Lanka signal tower banner",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(148.dp),
                contentScale = ContentScale.Crop
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(148.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                ObsidianBg.copy(alpha = 0.25f),
                                ObsidianBg.copy(alpha = 0.88f)
                            )
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = SignalEmerald.copy(alpha = 0.2f),
                        border = BorderStroke(1.dp, SignalEmerald.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.WifiOff,
                                contentDescription = null,
                                tint = SignalEmerald,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "NO DATA NEEDED",
                                style = MaterialTheme.typography.labelSmall,
                                color = SignalEmerald,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.MyLocation,
                            contentDescription = null,
                            tint = SignalCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = if (locationSnapshot.hasCoordinates) {
                                String.format(
                                    Locale.US,
                                    "%.4f, %.4f",
                                    locationSnapshot.latitude,
                                    locationSnapshot.longitude
                                )
                            } else {
                                locationSnapshot.providerLabel
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = TextPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(34.dp))

                Text(
                    text = "G-PINNER SRI LANKA",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary
                )
                Text(
                    text = "Find the strongest Dialog, Mobitel, Hutch or Airtel signal at your exact spot.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                if (insertedSims.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        insertedSims.forEach { sim ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = SlateSurfaceHigh.copy(alpha = 0.9f),
                                border = BorderStroke(1.dp, sim.mappedCarrier.brandColor.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.SimCard,
                                        contentDescription = null,
                                        tint = sim.mappedCarrier.brandColor,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = "SIM${sim.slotIndex}: ${sim.carrierName}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionPromptCard(onGrantClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SignalCyan.copy(alpha = 0.1f)),
        border = BorderStroke(1.dp, SignalCyan.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.LocationOn,
                    contentDescription = null,
                    tint = SignalCyan,
                    modifier = Modifier.size(26.dp)
                )
                Text(
                    text = stringResource(R.string.permission_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
            }
            Text(
                text = stringResource(R.string.permission_desc),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Button(
                onClick = onGrantClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("grant_permission_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = SignalCyan,
                    contentColor = ObsidianBg
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = stringResource(R.string.grant_permission),
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
private fun BestCarrierHeroCard(
    best: CarrierSummary,
    totalTowers: Int,
    hasSriLankaTowers: Boolean,
    onPinClick: () -> Unit
) {
    val accent = best.carrier.brandColor
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = SlateSurfaceElevated),
        border = BorderStroke(1.5.dp, accent.copy(alpha = 0.75f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            accent.copy(alpha = 0.18f),
                            SlateSurfaceElevated
                        )
                    )
                )
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = SignalEmerald.copy(alpha = 0.18f),
                    border = BorderStroke(1.dp, SignalEmerald.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Verified,
                            contentDescription = null,
                            tint = SignalEmerald,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = stringResource(R.string.best_sim_badge),
                            style = MaterialTheme.typography.labelSmall,
                            color = SignalEmerald,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                SignalQualityPill(dbm = best.bestDbm, label = best.qualityLabel)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = best.displayTitle,
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${best.bestNetworkType} • MCC-MNC ${best.mccMnc} • ${best.towerCount} tower(s)",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    AnimatedSignalBars(
                        bars = best.bars,
                        accentColor = accent,
                        barWidth = 6.dp,
                        maxHeight = 30.dp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${best.bestDbm} dBm",
                        style = MaterialTheme.typography.titleMedium,
                        color = accent,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (!hasSriLankaTowers) {
                Text(
                    text = "Note: Non-Sri Lankan MCC detected (${best.mccMnc}). Sri Lanka towers use MCC 413.",
                    style = MaterialTheme.typography.labelSmall,
                    color = SignalAmber
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Signal Score: ${best.qualityPercent}% ($totalTowers towers read)",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
                OutlinedButton(
                    onClick = onPinClick,
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("pin_spot_button"),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SignalCyan.copy(alpha = 0.7f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = SignalCyan)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.BookmarkAdd,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.pin_this_spot),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

@Composable
private fun CarrierComparisonCard(
    rank: Int,
    summary: CarrierSummary
) {
    var expanded by remember { mutableStateOf(false) }
    var barTarget by remember { mutableStateOf(0f) }
    LaunchedEffect(summary.qualityPercent) {
        barTarget = summary.qualityPercent / 100f
    }
    val animatedFill by animateFloatAsState(
        targetValue = barTarget,
        animationSpec = spring(dampingRatio = 0.75f, stiffness = 200f),
        label = "carrier_fill"
    )
    val accent = summary.carrier.brandColor
    val meterColor = signalStrengthColor(summary.bestDbm)

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SlateSurface),
        border = BorderStroke(1.dp, if (rank == 1) accent.copy(alpha = 0.55f) else SlateBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .testTag("carrier_card_$rank")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(accent.copy(alpha = 0.18f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "#$rank",
                            style = MaterialTheme.typography.labelLarge,
                            color = accent
                        )
                    }
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = summary.displayTitle,
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                            if (summary.isRegisteredSim) {
                                Icon(
                                    imageVector = Icons.Rounded.CheckCircle,
                                    contentDescription = "Active SIM network",
                                    tint = SignalEmerald,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                        Text(
                            text = "${summary.bestNetworkType} • ${summary.mccMnc} • ${summary.towerCount} tower(s)",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AnimatedSignalBars(
                        bars = summary.bars,
                        accentColor = meterColor,
                        barWidth = 4.dp,
                        maxHeight = 22.dp
                    )
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${summary.bestDbm} dBm",
                            style = MaterialTheme.typography.labelLarge,
                            color = meterColor
                        )
                        Text(
                            text = "${summary.qualityPercent}%",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }
                    Icon(
                        imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                        contentDescription = "Toggle tower details",
                        tint = TextSecondary
                    )
                }
            }

            // Animated horizontal strength meter
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(RoundedCornerShape(50))
                    .background(SlateSurfaceHigh)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(animatedFill.coerceIn(0.04f, 1f))
                        .height(7.dp)
                        .clip(RoundedCornerShape(50))
                        .background(
                            Brush.horizontalGradient(listOf(accent, meterColor))
                        )
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically() + fadeIn(),
            ) {
                Column(
                    modifier = Modifier.padding(top = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    HorizontalDivider(color = SlateBorder)
                    Text(
                        text = summary.carrier.primaryBands,
                        style = MaterialTheme.typography.labelSmall,
                        color = SignalCyan
                    )
                    summary.towers.take(4).forEach { tower ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${tower.networkType} • CI ${tower.cellId} • ${tower.pciOrPsc}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                            Text(
                                text = "${tower.dbm} dBm (ASU ${tower.asu})",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NoTowersDiagnosticCard(
    reason: String,
    operatorHint: String?
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = SlateSurface),
        border = BorderStroke(1.dp, SlateBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.CellTower,
                    contentDescription = null,
                    tint = SignalAmber
                )
                Text(
                    text = "No Live Cell Broadcasts Returned",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
            }
            Text(
                text = reason,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            if (!operatorHint.isNullOrBlank()) {
                Text(
                    text = "Modem Operator Hint: $operatorHint",
                    style = MaterialTheme.typography.labelMedium,
                    color = SignalCyan
                )
            }
        }
    }
}

@Composable
private fun LabPreviewToggleCard(
    isPreviewMode: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SlateSurface.copy(alpha = 0.7f)),
        border = BorderStroke(1.dp, SlateBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Science,
                    contentDescription = null,
                    tint = if (isPreviewMode) SignalAmber else TextSecondary
                )
                Column {
                    Text(
                        text = "Emulator / Lab Preview Mode",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = "Simulate Sri Lanka towers if testing on an emulator",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            }
            Switch(
                checked = isPreviewMode,
                onCheckedChange = onToggle,
                modifier = Modifier.testTag("preview_mode_switch"),
                colors = SwitchDefaults.colors(
                    checkedThumbColor = ObsidianBg,
                    checkedTrackColor = SignalAmber
                )
            )
        }
    }
}
