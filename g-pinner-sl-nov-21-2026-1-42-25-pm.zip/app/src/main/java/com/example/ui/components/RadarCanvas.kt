package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.CarrierSummary
import com.example.ui.theme.SignalAmber
import com.example.ui.theme.SignalCoral
import com.example.ui.theme.SignalCyan
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun TacticalRadarVisualizer(
    isScanning: Boolean,
    bestCarrier: CarrierSummary?,
    rankedCarriers: List<CarrierSummary>,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "radar_transition")

    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isScanning) 1400 else 5500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radar_sweep"
    )

    val pulseProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isScanning) 1200 else 2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radar_pulse"
    )

    val accentColor = bestCarrier?.carrier?.brandColor ?: SignalCyan

    Box(
        modifier = modifier.size(224.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = size.minDimension / 2f - 8.dp.toPx()

            // Outer radial glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        accentColor.copy(alpha = if (isScanning) 0.20f else 0.12f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = maxRadius
                ),
                radius = maxRadius,
                center = center
            )

            // Concentric tactical rings
            val ringFractions = listOf(0.32f, 0.56f, 0.78f, 1.0f)
            ringFractions.forEach { frac ->
                drawCircle(
                    color = SlateBorder.copy(alpha = 0.65f),
                    radius = maxRadius * frac,
                    center = center,
                    style = Stroke(width = 1.dp.toPx())
                )
            }

            // Crosshairs
            drawLine(
                color = SlateBorder.copy(alpha = 0.45f),
                start = Offset(center.x - maxRadius, center.y),
                end = Offset(center.x + maxRadius, center.y),
                strokeWidth = 1.dp.toPx()
            )
            drawLine(
                color = SlateBorder.copy(alpha = 0.45f),
                start = Offset(center.x, center.y - maxRadius),
                end = Offset(center.x, center.y + maxRadius),
                strokeWidth = 1.dp.toPx()
            )

            // Expanding sonar ring
            val pulseRadius = maxRadius * (0.22f + 0.78f * pulseProgress)
            drawCircle(
                color = accentColor.copy(alpha = (1f - pulseProgress) * (if (isScanning) 0.65f else 0.32f)),
                radius = pulseRadius,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )

            // Sweeping radar cone
            drawArc(
                brush = Brush.sweepGradient(
                    0.0f to Color.Transparent,
                    0.75f to Color.Transparent,
                    0.96f to accentColor.copy(alpha = if (isScanning) 0.42f else 0.18f),
                    1.0f to accentColor.copy(alpha = if (isScanning) 0.75f else 0.30f),
                    center = center
                ),
                startAngle = sweepAngle - 90f,
                sweepAngle = 90f,
                useCenter = true,
                topLeft = Offset(center.x - maxRadius, center.y - maxRadius),
                size = Size(maxRadius * 2f, maxRadius * 2f)
            )

            // Sweep leading line
            val rad = Math.toRadians(sweepAngle.toDouble())
            val endX = center.x + (maxRadius * cos(rad)).toFloat()
            val endY = center.y + (maxRadius * sin(rad)).toFloat()
            drawLine(
                color = accentColor.copy(alpha = if (isScanning) 0.9f else 0.45f),
                start = center,
                end = Offset(endX, endY),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )

            // Carrier signal blips positioned by relative dBm distance from center
            rankedCarriers.take(5).forEachIndexed { index, summary ->
                val angleDeg = (index * 72f) - 65f
                val angleRad = Math.toRadians(angleDeg.toDouble())
                // Stronger signals sit closer to center
                val distanceFactor = (1.12f - (summary.qualityPercent / 100f) * 0.68f).coerceIn(0.36f, 0.92f)
                val bx = center.x + (maxRadius * distanceFactor * cos(angleRad)).toFloat()
                val by = center.y + (maxRadius * distanceFactor * sin(angleRad)).toFloat()
                val blipColor = summary.carrier.brandColor
                drawCircle(
                    color = blipColor.copy(alpha = 0.28f),
                    radius = if (index == 0) 11.dp.toPx() else 8.dp.toPx(),
                    center = Offset(bx, by)
                )
                drawCircle(
                    color = blipColor,
                    radius = if (index == 0) 5.5.dp.toPx() else 4.dp.toPx(),
                    center = Offset(bx, by)
                )
            }

            // Center hub ring
            drawCircle(
                color = SlateSurfaceElevated,
                radius = 44.dp.toPx(),
                center = center
            )
            drawCircle(
                color = accentColor.copy(alpha = 0.85f),
                radius = 44.dp.toPx(),
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )
        }

        // Center Telemetry Readout
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (isScanning) {
                Text(
                    text = "RF",
                    style = MaterialTheme.typography.labelMedium,
                    color = SignalCyan
                )
                Text(
                    text = "SCAN",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
            } else if (bestCarrier != null) {
                Text(
                    text = "${bestCarrier.bestDbm}",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "dBm",
                    style = MaterialTheme.typography.labelSmall,
                    color = bestCarrier.carrier.brandColor
                )
            } else {
                Text(
                    text = "READY",
                    style = MaterialTheme.typography.labelLarge,
                    color = SignalCyan
                )
                Text(
                    text = "OFFLINE",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
fun AnimatedSignalBars(
    bars: Int,
    accentColor: Color,
    modifier: Modifier = Modifier,
    barWidth: Dp = 5.dp,
    maxHeight: Dp = 24.dp
) {
    Row(
        modifier = modifier.height(maxHeight),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        for (level in 1..5) {
            val isActive = level <= bars
            val targetFraction = if (isActive) 1f else 0.85f
            val animatedScale by animateFloatAsState(
                targetValue = targetFraction,
                animationSpec = spring(dampingRatio = 0.65f, stiffness = 320f),
                label = "bar_$level"
            )
            val barHeight = maxHeight * (0.28f + (level - 1) * 0.18f) * animatedScale
            Box(
                modifier = Modifier
                    .width(barWidth)
                    .height(barHeight)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (isActive) accentColor else SlateBorder.copy(alpha = 0.55f))
            )
        }
    }
}

@Composable
fun SignalQualityPill(
    dbm: Int,
    label: String,
    modifier: Modifier = Modifier
) {
    val pillColor = when {
        dbm >= -85 -> SignalEmerald
        dbm >= -98 -> SignalAmber
        else -> SignalCoral
    }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(pillColor.copy(alpha = 0.16f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = label.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = pillColor,
            fontWeight = FontWeight.Bold
        )
    }
}

fun signalStrengthColor(dbm: Int): Color = when {
    dbm >= -85 -> SignalEmerald
    dbm >= -98 -> SignalAmber
    else -> SignalCoral
}
