package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SignalPinRepository
import com.example.data.SignalScannerService
import com.example.data.SriLankaCarrierMapper
import com.example.data.local.AppDatabase
import com.example.data.local.SignalPinEntity
import com.example.model.InsertedSimInfo
import com.example.model.LocationSnapshot
import com.example.model.ScanUiState
import com.example.model.SriLankaCarrier
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ScannerViewModel(application: Application) : AndroidViewModel(application) {

    private val scannerService = SignalScannerService(application)
    private val repository = SignalPinRepository(AppDatabase.getInstance(application).signalPinDao())

    private val _hasLocationPermission = MutableStateFlow(scannerService.hasLocationPermission())
    val hasLocationPermission: StateFlow<Boolean> = _hasLocationPermission.asStateFlow()

    private val _hasFineLocation = MutableStateFlow(scannerService.hasFineLocationPermission())
    val hasFineLocation: StateFlow<Boolean> = _hasFineLocation.asStateFlow()

    private val _scanState = MutableStateFlow<ScanUiState>(ScanUiState.Idle)
    val scanState: StateFlow<ScanUiState> = _scanState.asStateFlow()

    private val _insertedSims = MutableStateFlow<List<InsertedSimInfo>>(emptyList())
    val insertedSims: StateFlow<List<InsertedSimInfo>> = _insertedSims.asStateFlow()

    private val _locationSnapshot = MutableStateFlow(
        LocationSnapshot(null, null, null, "Waiting for scan")
    )
    val locationSnapshot: StateFlow<LocationSnapshot> = _locationSnapshot.asStateFlow()

    private val _isPreviewMode = MutableStateFlow(false)
    val isPreviewMode: StateFlow<Boolean> = _isPreviewMode.asStateFlow()

    private val _pinFeedbackMessage = MutableStateFlow<String?>(null)
    val pinFeedbackMessage: StateFlow<String?> = _pinFeedbackMessage.asStateFlow()

    private val _liveMode = MutableStateFlow(true)
    val liveMode: StateFlow<Boolean> = _liveMode.asStateFlow()
    private var liveJob: Job? = null

    val savedPins: StateFlow<List<SignalPinEntity>> = repository.allPins.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    init {
        refreshPermissionsAndSims()
    }

    fun refreshPermissionsAndSims() {
        _hasLocationPermission.value = scannerService.hasLocationPermission()
        _hasFineLocation.value = scannerService.hasFineLocationPermission()
        _insertedSims.value = scannerService.readInsertedSims()
    }

    fun onPermissionsResult() {
        refreshPermissionsAndSims()
        if (_hasLocationPermission.value) {
            startScan()
        }
    }

    fun togglePreviewMode(enabled: Boolean) {
        _isPreviewMode.value = enabled
        startScan()
    }

    fun startScan() {
        refreshPermissionsAndSims()
        if (!_isPreviewMode.value && !_hasLocationPermission.value) {
            _scanState.value = ScanUiState.Idle
            return
        }

        viewModelScope.launch {
            _scanState.value = ScanUiState.Scanning(
                progress = 0.18f,
                statusMessage = "Locking RF modem channels (Offline)..."
            )
            delay(320)

            _scanState.value = ScanUiState.Scanning(
                progress = 0.52f,
                statusMessage = "Sampling Dialog, Mobitel, Hutch & Airtel towers..."
            )
            val loc = scannerService.readOfflineLocation()
            _locationSnapshot.value = loc

            val outcome = if (_isPreviewMode.value) {
                com.example.data.RawRfScanOutcome(
                    readings = scannerService.buildLabPreviewReadings(),
                    activeOperatorHint = "Sri Lanka Lab Preview"
                )
            } else {
                scannerService.scanCellTowers()
            }

            delay(350)
            _scanState.value = ScanUiState.Scanning(
                progress = 0.88f,
                statusMessage = "Ranking strongest dBm signal..."
            )
            delay(220)

            if (outcome.readings.isEmpty()) {
                _scanState.value = ScanUiState.NoTowers(
                    reason = "No cellular tower broadcasts were returned by the device radio. On Android emulators or airplane mode without radio, TelephonyManager reports 0 towers.",
                    activeOperatorHint = outcome.activeOperatorHint
                )
            } else {
                val ranked = SriLankaCarrierMapper.aggregateCarriers(outcome.readings)
                val best = ranked.first()
                val hasSl = ranked.any { it.carrier != SriLankaCarrier.OTHER }
                _scanState.value = ScanUiState.Results(
                    bestCarrier = best,
                    rankedCarriers = ranked,
                    totalTowersScanned = outcome.readings.size,
                    hasSriLankaTowers = hasSl,
                    isPreviewMode = _isPreviewMode.value,
                    scannedAtMillis = System.currentTimeMillis()
                )
            }
        }
    }

    // ---------- LIVE (real-time) mode ----------
    fun setLiveMode(enabled: Boolean) {
        _liveMode.value = enabled
        if (enabled) startLive() else stopLive()
    }

    fun startLive() {
        if (!_liveMode.value) return
        if (liveJob?.isActive == true) return
        liveJob = viewModelScope.launch {
            while (true) {
                val canScan = _isPreviewMode.value || scannerService.hasLocationPermission()
                if (canScan && _scanState.value !is ScanUiState.Scanning) {
                    runCatching { liveRefresh() }
                }
                delay(3000)
            }
        }
    }

    fun stopLive() {
        liveJob?.cancel()
        liveJob = null
    }

    private suspend fun liveRefresh() {
        _insertedSims.value = scannerService.readInsertedSims()
        _locationSnapshot.value = scannerService.readOfflineLocation()

        val outcome = if (_isPreviewMode.value) {
            com.example.data.RawRfScanOutcome(
                readings = scannerService.buildLabPreviewReadings(),
                activeOperatorHint = "Sri Lanka Lab Preview"
            )
        } else {
            scannerService.scanCellTowers()
        }

        // A manual scan started while we were reading: do not overwrite its animation.
        if (_scanState.value is ScanUiState.Scanning) return

        if (outcome.readings.isEmpty()) {
            val current = _scanState.value
            if (current is ScanUiState.Idle || current is ScanUiState.NoTowers) {
                _scanState.value = ScanUiState.NoTowers(
                    reason = "No cellular tower broadcasts were returned by the device radio. On Android emulators or airplane mode without radio, TelephonyManager reports 0 towers.",
                    activeOperatorHint = outcome.activeOperatorHint
                )
            }
            return
        }

        val ranked = SriLankaCarrierMapper.aggregateCarriers(outcome.readings)
        _scanState.value = ScanUiState.Results(
            bestCarrier = ranked.first(),
            rankedCarriers = ranked,
            totalTowersScanned = outcome.readings.size,
            hasSriLankaTowers = ranked.any { it.carrier != SriLankaCarrier.OTHER },
            isPreviewMode = _isPreviewMode.value,
            scannedAtMillis = System.currentTimeMillis()
        )
    }

    override fun onCleared() {
        stopLive()
        super.onCleared()
    }

    fun saveCurrentPin(locationLabel: String) {
        val current = _scanState.value as? ScanUiState.Results ?: return
        val cleanLabel = locationLabel.trim().ifEmpty { "Pinned Spot" }
        val comparison = current.rankedCarriers.joinToString(" • ") {
            "${it.carrier.shortName.takeIf { s -> s != "Other" } ?: it.displayTitle}: ${it.bestDbm} dBm"
        }
        val loc = _locationSnapshot.value

        viewModelScope.launch {
            repository.savePin(
                SignalPinEntity(
                    locationLabel = cleanLabel,
                    bestCarrierName = current.bestCarrier.displayTitle,
                    bestCarrierShort = if (current.bestCarrier.carrier != SriLankaCarrier.OTHER) {
                        current.bestCarrier.carrier.shortName
                    } else {
                        current.bestCarrier.displayTitle
                    },
                    bestDbm = current.bestCarrier.bestDbm,
                    bestNetworkType = current.bestCarrier.bestNetworkType,
                    qualityPercent = current.bestCarrier.qualityPercent,
                    comparisonSummary = comparison,
                    latitude = loc.latitude,
                    longitude = loc.longitude,
                    isPreviewPin = current.isPreviewMode
                )
            )
            _pinFeedbackMessage.value = "Pinned \"$cleanLabel\" (${current.bestCarrier.displayTitle} ${current.bestCarrier.bestDbm} dBm)"
        }
    }

    fun deletePin(id: Long) {
        viewModelScope.launch {
            repository.deletePin(id)
        }
    }

    fun clearPinFeedback() {
        _pinFeedbackMessage.value = null
    }
}
