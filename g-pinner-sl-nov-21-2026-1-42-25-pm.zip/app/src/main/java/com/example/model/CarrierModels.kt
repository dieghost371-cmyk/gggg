package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.CarrierAirtel
import com.example.ui.theme.CarrierDialog
import com.example.ui.theme.CarrierHutch
import com.example.ui.theme.CarrierMobitel
import com.example.ui.theme.CarrierOther
import com.example.ui.theme.CarrierSlt

enum class SriLankaCarrier(
    val displayName: String,
    val shortName: String,
    val mccMncCodes: List<String>,
    val primaryBands: String,
    val brandColor: Color
) {
    DIALOG(
        displayName = "Dialog Axiata",
        shortName = "Dialog",
        mccMncCodes = listOf("413-02", "413-11"),
        primaryBands = "4G B3 (1800) / B1 / B40 • 5G Trial",
        brandColor = CarrierDialog
    ),
    MOBITEL(
        displayName = "SLT-Mobitel",
        shortName = "Mobitel",
        mccMncCodes = listOf("413-01"),
        primaryBands = "4G B3 (1800) / B1 / B8 • 5G Trial",
        brandColor = CarrierMobitel
    ),
    HUTCH(
        displayName = "Hutch (SL)",
        shortName = "Hutch",
        mccMncCodes = listOf("413-08", "413-03"),
        primaryBands = "4G B3 (1800) / B8 (900) • 3G",
        brandColor = CarrierHutch
    ),
    AIRTEL(
        displayName = "Airtel Lanka",
        shortName = "Airtel",
        mccMncCodes = listOf("413-05"),
        primaryBands = "4G B1 (2100) / B3 (1800) • 3G",
        brandColor = CarrierAirtel
    ),
    SLT(
        displayName = "SLT 4G LTE",
        shortName = "SLT",
        mccMncCodes = listOf("413-12"),
        primaryBands = "4G TDD B38 / B40 / B41",
        brandColor = CarrierSlt
    ),
    OTHER(
        displayName = "Detected Network",
        shortName = "Other",
        mccMncCodes = emptyList(),
        primaryBands = "Non-413 / Unmapped Carrier",
        brandColor = CarrierOther
    )
}

data class CellTowerReading(
    val carrier: SriLankaCarrier,
    val operatorName: String,
    val mccMnc: String,
    val networkType: String,
    val dbm: Int,
    val asu: Int,
    val bars: Int,
    val qualityPercent: Int,
    val qualityLabel: String,
    val isRegistered: Boolean,
    val cellId: String,
    val pciOrPsc: String,
    val tacOrLac: String
)

data class CarrierSummary(
    val carrier: SriLankaCarrier,
    val displayTitle: String,
    val mccMnc: String,
    val bestDbm: Int,
    val averageDbm: Int,
    val towerCount: Int,
    val bestNetworkType: String,
    val qualityPercent: Int,
    val bars: Int,
    val qualityLabel: String,
    val isRegisteredSim: Boolean,
    val towers: List<CellTowerReading>
)

data class InsertedSimInfo(
    val slotIndex: Int,
    val carrierName: String,
    val mappedCarrier: SriLankaCarrier,
    val mccMnc: String
)

data class LocationSnapshot(
    val latitude: Double?,
    val longitude: Double?,
    val accuracyMeters: Float?,
    val providerLabel: String
) {
    val hasCoordinates: Boolean
        get() = latitude != null && longitude != null
}

sealed interface ScanUiState {
    data object Idle : ScanUiState
    data class Scanning(val progress: Float, val statusMessage: String) : ScanUiState
    data class Results(
        val bestCarrier: CarrierSummary,
        val rankedCarriers: List<CarrierSummary>,
        val totalTowersScanned: Int,
        val hasSriLankaTowers: Boolean,
        val isPreviewMode: Boolean,
        val scannedAtMillis: Long
    ) : ScanUiState
    data class NoTowers(
        val reason: String,
        val activeOperatorHint: String?
    ) : ScanUiState
}
