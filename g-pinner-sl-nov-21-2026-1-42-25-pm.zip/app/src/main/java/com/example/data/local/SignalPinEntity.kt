package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "signal_pins")
data class SignalPinEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val locationLabel: String,
    val bestCarrierName: String,
    val bestCarrierShort: String,
    val bestDbm: Int,
    val bestNetworkType: String,
    val qualityPercent: Int,
    val comparisonSummary: String,
    val latitude: Double?,
    val longitude: Double?,
    val isPreviewPin: Boolean = false,
    val timestampMillis: Long = System.currentTimeMillis()
)
