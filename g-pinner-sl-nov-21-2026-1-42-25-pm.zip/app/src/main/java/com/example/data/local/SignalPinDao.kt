package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SignalPinDao {
    @Query("SELECT * FROM signal_pins ORDER BY timestampMillis DESC")
    fun observeAllPins(): Flow<List<SignalPinEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPin(pin: SignalPinEntity)

    @Query("DELETE FROM signal_pins WHERE id = :id")
    suspend fun deletePinById(id: Long)

    @Query("DELETE FROM signal_pins")
    suspend fun clearAll()
}
