package com.example.data

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.telephony.CellInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import com.example.model.CellTowerReading
import com.example.model.InsertedSimInfo
import com.example.model.LocationSnapshot
import com.example.model.SriLankaCarrier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

data class RawRfScanOutcome(
    val readings: List<CellTowerReading>,
    val activeOperatorHint: String?
)

class SignalScannerService(private val context: Context) {

    fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    fun hasFineLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasPhoneStatePermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED
    }

    @SuppressLint("MissingPermission")
    suspend fun scanCellTowers(): RawRfScanOutcome = withContext(Dispatchers.IO) {
        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            ?: return@withContext RawRfScanOutcome(emptyList(), null)

        val operatorHint = runCatching {
            tm.networkOperatorName?.takeIf { it.isNotBlank() }
                ?: tm.simOperatorName?.takeIf { it.isNotBlank() }
        }.getOrNull()

        if (!hasLocationPermission()) {
            return@withContext RawRfScanOutcome(emptyList(), operatorHint)
        }

        val cellInfos: List<CellInfo> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val fresh = withTimeoutOrNull(2500L) {
                requestFreshCellInfo(tm)
            }
            fresh ?: runCatching { tm.allCellInfo.orEmpty() }.getOrDefault(emptyList())
        } else {
            @Suppress("DEPRECATION")
            runCatching { tm.allCellInfo.orEmpty() }.getOrDefault(emptyList())
        }

        val parsed = cellInfos.mapNotNull { SriLankaCarrierMapper.parseCellInfo(it) }
        RawRfScanOutcome(
            readings = parsed.sortedByDescending { it.dbm },
            activeOperatorHint = operatorHint
        )
    }

    @SuppressLint("MissingPermission")
    private suspend fun requestFreshCellInfo(tm: TelephonyManager): List<CellInfo> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return emptyList()
        return suspendCancellableCoroutine { cont ->
            try {
                tm.requestCellInfoUpdate(
                    ContextCompat.getMainExecutor(context),
                    object : TelephonyManager.CellInfoCallback() {
                        override fun onCellInfo(cellInfo: MutableList<CellInfo>) {
                            if (cont.isActive) cont.resume(cellInfo.toList())
                        }

                        override fun onError(errorCode: Int, detail: Throwable?) {
                            val fallback = runCatching { tm.allCellInfo.orEmpty() }.getOrDefault(emptyList())
                            if (cont.isActive) cont.resume(fallback)
                        }
                    }
                )
            } catch (_: Throwable) {
                val fallback = runCatching { tm.allCellInfo.orEmpty() }.getOrDefault(emptyList())
                if (cont.isActive) cont.resume(fallback)
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun readInsertedSims(): List<InsertedSimInfo> {
        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        if (hasPhoneStatePermission()) {
            val sm = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? SubscriptionManager
            val list = runCatching { sm?.activeSubscriptionInfoList }.getOrNull()
            if (!list.isNullOrEmpty()) {
                return list.mapIndexed { idx, sub ->
                    val name = sub.carrierName?.toString()?.takeIf { it.isNotBlank() }
                        ?: sub.displayName?.toString()
                        ?: "SIM ${idx + 1}"
                    val mcc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) sub.mccString else null
                    val mnc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) sub.mncString else null
                    val mapped = SriLankaCarrierMapper.mapMccMncToCarrier(mcc, mnc, name)
                    InsertedSimInfo(
                        slotIndex = sub.simSlotIndex + 1,
                        carrierName = if (mapped != SriLankaCarrier.OTHER) mapped.shortName else name,
                        mappedCarrier = mapped,
                        mccMnc = listOfNotNull(mcc, mnc).joinToString("-").ifBlank { "—" }
                    )
                }
            }
        }
        val fallbackOp = runCatching { tm?.simOperatorName?.takeIf { it.isNotBlank() } }.getOrNull()
        val fallbackMccMnc = runCatching { tm?.simOperator?.takeIf { it.length >= 5 } }.getOrNull()
        if (fallbackOp != null || fallbackMccMnc != null) {
            val mcc = fallbackMccMnc?.substring(0, 3)
            val mnc = fallbackMccMnc?.substring(3)
            val mapped = SriLankaCarrierMapper.mapMccMncToCarrier(mcc, mnc, fallbackOp)
            return listOf(
                InsertedSimInfo(
                    slotIndex = 1,
                    carrierName = if (mapped != SriLankaCarrier.OTHER) mapped.shortName else (fallbackOp ?: "Active SIM"),
                    mappedCarrier = mapped,
                    mccMnc = if (mcc != null && mnc != null) "$mcc-$mnc" else "—"
                )
            )
        }
        return emptyList()
    }

    @SuppressLint("MissingPermission")
    suspend fun readOfflineLocation(): LocationSnapshot = withContext(Dispatchers.IO) {
        if (!hasLocationPermission()) {
            return@withContext LocationSnapshot(null, null, null, "Permission Needed")
        }
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            ?: return@withContext LocationSnapshot(null, null, null, "Unavailable")

        val candidates = listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        ).mapNotNull { provider ->
            runCatching {
                if (lm.isProviderEnabled(provider)) lm.getLastKnownLocation(provider) else null
            }.getOrNull()
        }

        val best: Location? = candidates.maxByOrNull { it.time }
        if (best != null) {
            val providerName = when (best.provider) {
                LocationManager.GPS_PROVIDER -> "Offline GPS"
                LocationManager.NETWORK_PROVIDER -> "Cell Tower Fix"
                else -> "Last Fix"
            }
            LocationSnapshot(
                latitude = best.latitude,
                longitude = best.longitude,
                accuracyMeters = if (best.hasAccuracy()) best.accuracy else null,
                providerLabel = providerName
            )
        } else {
            LocationSnapshot(null, null, null, "GPS Warming Up (Offline)")
        }
    }

    /**
     * Explicit, user-toggled Preview Mode for testing UI ranking on Android emulators
     * or devices outside Sri Lanka where MCC 413 cellular towers are not physically in range.
     * Never mixed into live radio scan results.
     */
    fun buildLabPreviewReadings(): List<CellTowerReading> {
        val raw = listOf(
            CellTowerReading(
                carrier = SriLankaCarrier.HUTCH,
                operatorName = SriLankaCarrier.HUTCH.displayName,
                mccMnc = "413-08",
                networkType = "4G LTE",
                dbm = -71,
                asu = 69,
                bars = SriLankaCarrierMapper.dbmToBars(-71),
                qualityPercent = SriLankaCarrierMapper.normalizeDbmToPercent(-71),
                qualityLabel = SriLankaCarrierMapper.dbmToQualityLabel(-71),
                isRegistered = true,
                cellId = "2841901",
                pciOrPsc = "PCI 142",
                tacOrLac = "TAC 4102"
            ),
            CellTowerReading(
                carrier = SriLankaCarrier.DIALOG,
                operatorName = SriLankaCarrier.DIALOG.displayName,
                mccMnc = "413-02",
                networkType = "4G LTE",
                dbm = -82,
                asu = 58,
                bars = SriLankaCarrierMapper.dbmToBars(-82),
                qualityPercent = SriLankaCarrierMapper.normalizeDbmToPercent(-82),
                qualityLabel = SriLankaCarrierMapper.dbmToQualityLabel(-82),
                isRegistered = false,
                cellId = "1940214",
                pciOrPsc = "PCI 88",
                tacOrLac = "TAC 2019"
            ),
            CellTowerReading(
                carrier = SriLankaCarrier.MOBITEL,
                operatorName = SriLankaCarrier.MOBITEL.displayName,
                mccMnc = "413-01",
                networkType = "4G LTE",
                dbm = -89,
                asu = 51,
                bars = SriLankaCarrierMapper.dbmToBars(-89),
                qualityPercent = SriLankaCarrierMapper.normalizeDbmToPercent(-89),
                qualityLabel = SriLankaCarrierMapper.dbmToQualityLabel(-89),
                isRegistered = false,
                cellId = "3104822",
                pciOrPsc = "PCI 311",
                tacOrLac = "TAC 1104"
            ),
            CellTowerReading(
                carrier = SriLankaCarrier.AIRTEL,
                operatorName = SriLankaCarrier.AIRTEL.displayName,
                mccMnc = "413-05",
                networkType = "4G LTE",
                dbm = -98,
                asu = 42,
                bars = SriLankaCarrierMapper.dbmToBars(-98),
                qualityPercent = SriLankaCarrierMapper.normalizeDbmToPercent(-98),
                qualityLabel = SriLankaCarrierMapper.dbmToQualityLabel(-98),
                isRegistered = false,
                cellId = "5501920",
                pciOrPsc = "PCI 204",
                tacOrLac = "TAC 5100"
            )
        )
        return raw.sortedByDescending { it.dbm }
    }
}
