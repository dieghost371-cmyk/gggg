package com.example.data

import com.example.data.local.SignalPinDao
import com.example.data.local.SignalPinEntity
import kotlinx.coroutines.flow.Flow

class SignalPinRepository(private val dao: SignalPinDao) {
    val allPins: Flow<List<SignalPinEntity>> = dao.observeAllPins()

    suspend fun savePin(pin: SignalPinEntity) {
        dao.insertPin(pin)
    }

    suspend fun deletePin(id: Long) {
        dao.deletePinById(id)
    }
}
