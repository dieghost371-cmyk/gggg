package com.example.data

import android.os.Build
import android.telephony.CellInfo
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.CellIdentityNr
import android.telephony.CellSignalStrengthNr
import com.example.model.CarrierSummary
import com.example.model.CellTowerReading
import com.example.model.SriLankaCarrier
import kotlin.math.roundToInt

object SriLankaCarrierMapper {

    fun mapMccMncToCarrier(mcc: String?, mnc: String?, rawOperatorName: String? = null): SriLankaCarrier {
        val cleanMcc = mcc?.trim().orEmpty()
        val cleanMnc = mnc?.trim().orEmpty()
        val normalizedMnc = cleanMnc.toIntOrNull()?.toString()?.padStart(2, '0') ?: cleanMnc

        if (cleanMcc == "413") {
            return when (normalizedMnc) {
                "01" -> SriLankaCarrier.MOBITEL
                "02", "11" -> SriLankaCarrier.DIALOG
                "03", "08" -> SriLankaCarrier.HUTCH
                "05" -> SriLankaCarrier.AIRTEL
                "12" -> SriLankaCarrier.SLT
                else -> inferFromOperatorName(rawOperatorName)
            }
        }

        if (cleanMcc.isEmpty() && !rawOperatorName.isNullOrBlank()) {
            return inferFromOperatorName(rawOperatorName)
        }

        return inferFromOperatorName(rawOperatorName)
    }

    fun inferFromOperatorName(name: String?): SriLankaCarrier {
        val lower = name?.lowercase().orEmpty()
        return when {
            "dialog" in lower -> SriLankaCarrier.DIALOG
            "mobitel" in lower -> SriLankaCarrier.MOBITEL
            "hutch" in lower || "etisalat" in lower -> SriLankaCarrier.HUTCH
            "airtel" in lower -> SriLankaCarrier.AIRTEL
            "slt" in lower -> SriLankaCarrier.SLT
            else -> SriLankaCarrier.OTHER
        }
    }

    fun normalizeDbmToPercent(dbm: Int): Int {
        // Cellular RF typical range: -120 dBm (0%) to -55 dBm (100%)
        if (dbm >= -55) return 100
        if (dbm <= -122) return 4
        val fraction = (dbm - (-122)).toFloat() / (-55 - (-122)).toFloat()
        return (fraction * 96f + 4f).roundToInt().coerceIn(4, 100)
    }

    fun dbmToBars(dbm: Int): Int = when {
        dbm >= -75 -> 5
        dbm >= -85 -> 4
        dbm >= -95 -> 3
        dbm >= -105 -> 2
        dbm >= -116 -> 1
        else -> 0
    }

    fun dbmToQualityLabel(dbm: Int): String = when {
        dbm >= -75 -> "Excellent"
        dbm >= -85 -> "Very Good"
        dbm >= -95 -> "Good"
        dbm >= -105 -> "Fair"
        else -> "Weak"
    }

    @Suppress("DEPRECATION")
    fun parseCellInfo(cellInfo: CellInfo): CellTowerReading? {
        return when (cellInfo) {
            is CellInfoLte -> {
                val id = cellInfo.cellIdentity
                val ss = cellInfo.cellSignalStrength
                val dbm = sanitizeDbm(ss.dbm) ?: return null
                val mcc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mccString else id.mcc.takeIf { it != CellInfo.UNAVAILABLE && it > 0 }?.toString()
                val mnc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mncString else id.mnc.takeIf { it != CellInfo.UNAVAILABLE && it > 0 }?.toString()?.padStart(2, '0')
                val opAlpha = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.operatorAlphaLong?.toString() else null
                val carrier = mapMccMncToCarrier(mcc, mnc, opAlpha)
                val mccMnc = formatMccMnc(mcc, mnc)
                val operatorLabel = if (carrier != SriLankaCarrier.OTHER) carrier.displayName else (opAlpha?.takeIf { it.isNotBlank() } ?: "Tower $mccMnc")
                CellTowerReading(
                    carrier = carrier,
                    operatorName = operatorLabel,
                    mccMnc = mccMnc,
                    networkType = "4G LTE",
                    dbm = dbm,
                    asu = ss.asuLevel.takeIf { it != CellInfo.UNAVAILABLE } ?: ((dbm + 140).coerceIn(0, 97)),
                    bars = dbmToBars(dbm),
                    qualityPercent = normalizeDbmToPercent(dbm),
                    qualityLabel = dbmToQualityLabel(dbm),
                    isRegistered = cellInfo.isRegistered,
                    cellId = id.ci.takeIf { it != CellInfo.UNAVAILABLE }?.toString() ?: "—",
                    pciOrPsc = id.pci.takeIf { it != CellInfo.UNAVAILABLE }?.let { "PCI $it" } ?: "—",
                    tacOrLac = id.tac.takeIf { it != CellInfo.UNAVAILABLE }?.let { "TAC $it" } ?: "—"
                )
            }
            is CellInfoWcdma -> {
                val id = cellInfo.cellIdentity
                val ss = cellInfo.cellSignalStrength
                val dbm = sanitizeDbm(ss.dbm) ?: return null
                val mcc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mccString else id.mcc.takeIf { it != CellInfo.UNAVAILABLE && it > 0 }?.toString()
                val mnc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mncString else id.mnc.takeIf { it != CellInfo.UNAVAILABLE && it > 0 }?.toString()?.padStart(2, '0')
                val opAlpha = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.operatorAlphaLong?.toString() else null
                val carrier = mapMccMncToCarrier(mcc, mnc, opAlpha)
                val mccMnc = formatMccMnc(mcc, mnc)
                val operatorLabel = if (carrier != SriLankaCarrier.OTHER) carrier.displayName else (opAlpha?.takeIf { it.isNotBlank() } ?: "Tower $mccMnc")
                CellTowerReading(
                    carrier = carrier,
                    operatorName = operatorLabel,
                    mccMnc = mccMnc,
                    networkType = "3G HSPA",
                    dbm = dbm,
                    asu = ss.asuLevel.takeIf { it != CellInfo.UNAVAILABLE } ?: ((dbm + 113) / 2).coerceIn(0, 31),
                    bars = dbmToBars(dbm),
                    qualityPercent = normalizeDbmToPercent(dbm),
                    qualityLabel = dbmToQualityLabel(dbm),
                    isRegistered = cellInfo.isRegistered,
                    cellId = id.cid.takeIf { it != CellInfo.UNAVAILABLE }?.toString() ?: "—",
                    pciOrPsc = id.psc.takeIf { it != CellInfo.UNAVAILABLE }?.let { "PSC $it" } ?: "—",
                    tacOrLac = id.lac.takeIf { it != CellInfo.UNAVAILABLE }?.let { "LAC $it" } ?: "—"
                )
            }
            is CellInfoGsm -> {
                val id = cellInfo.cellIdentity
                val ss = cellInfo.cellSignalStrength
                val dbm = sanitizeDbm(ss.dbm) ?: return null
                val mcc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mccString else id.mcc.takeIf { it != CellInfo.UNAVAILABLE && it > 0 }?.toString()
                val mnc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.mncString else id.mnc.takeIf { it != CellInfo.UNAVAILABLE && it > 0 }?.toString()?.padStart(2, '0')
                val opAlpha = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) id.operatorAlphaLong?.toString() else null
                val carrier = mapMccMncToCarrier(mcc, mnc, opAlpha)
                val mccMnc = formatMccMnc(mcc, mnc)
                val operatorLabel = if (carrier != SriLankaCarrier.OTHER) carrier.displayName else (opAlpha?.takeIf { it.isNotBlank() } ?: "Tower $mccMnc")
                CellTowerReading(
                    carrier = carrier,
                    operatorName = operatorLabel,
                    mccMnc = mccMnc,
                    networkType = "2G GSM",
                    dbm = dbm,
                    asu = ss.asuLevel.takeIf { it != CellInfo.UNAVAILABLE } ?: ((dbm + 113) / 2).coerceIn(0, 31),
                    bars = dbmToBars(dbm),
                    qualityPercent = normalizeDbmToPercent(dbm),
                    qualityLabel = dbmToQualityLabel(dbm),
                    isRegistered = cellInfo.isRegistered,
                    cellId = id.cid.takeIf { it != CellInfo.UNAVAILABLE }?.toString() ?: "—",
                    pciOrPsc = "GSM",
                    tacOrLac = id.lac.takeIf { it != CellInfo.UNAVAILABLE }?.let { "LAC $it" } ?: "—"
                )
            }
            else -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && cellInfo is CellInfoNr) {
                    val id = cellInfo.cellIdentity as? CellIdentityNr ?: return null
                    val ss = cellInfo.cellSignalStrength as? CellSignalStrengthNr ?: return null
                    val dbm = sanitizeDbm(ss.dbm) ?: return null
                    val mcc = id.mccString
                    val mnc = id.mncString
                    val opAlpha = id.operatorAlphaLong?.toString()
                    val carrier = mapMccMncToCarrier(mcc, mnc, opAlpha)
                    val mccMnc = formatMccMnc(mcc, mnc)
                    val operatorLabel = if (carrier != SriLankaCarrier.OTHER) carrier.displayName else (opAlpha?.takeIf { it.isNotBlank() } ?: "5G Tower $mccMnc")
                    CellTowerReading(
                        carrier = carrier,
                        operatorName = operatorLabel,
                        mccMnc = mccMnc,
                        networkType = "5G NR",
                        dbm = dbm,
                        asu = ss.asuLevel.takeIf { it != CellInfo.UNAVAILABLE } ?: ((dbm + 140).coerceIn(0, 97)),
                        bars = dbmToBars(dbm),
                        qualityPercent = normalizeDbmToPercent(dbm),
                        qualityLabel = dbmToQualityLabel(dbm),
                        isRegistered = cellInfo.isRegistered,
                        cellId = id.nci.takeIf { it != CellInfo.UNAVAILABLE_LONG }?.toString() ?: "—",
                        pciOrPsc = id.pci.takeIf { it != CellInfo.UNAVAILABLE }?.let { "PCI $it" } ?: "—",
                        tacOrLac = id.tac.takeIf { it != CellInfo.UNAVAILABLE }?.let { "TAC $it" } ?: "—"
                    )
                } else {
                    null
                }
            }
        }
    }

    fun aggregateCarriers(readings: List<CellTowerReading>): List<CarrierSummary> {
        if (readings.isEmpty()) return emptyList()
        return readings
            .groupBy { reading ->
                if (reading.carrier != SriLankaCarrier.OTHER) {
                    reading.carrier.name
                } else {
                    "OTHER_${reading.mccMnc}_${reading.operatorName}"
                }
            }
            .values
            .map { group ->
                val sorted = group.sortedByDescending { it.dbm }
                val strongest = sorted.first()
                val avgDbm = sorted.map { it.dbm }.average().roundToInt()
                CarrierSummary(
                    carrier = strongest.carrier,
                    displayTitle = if (strongest.carrier != SriLankaCarrier.OTHER) strongest.carrier.displayName else strongest.operatorName,
                    mccMnc = strongest.mccMnc,
                    bestDbm = strongest.dbm,
                    averageDbm = avgDbm,
                    towerCount = sorted.size,
                    bestNetworkType = strongest.networkType,
                    qualityPercent = normalizeDbmToPercent(strongest.dbm),
                    bars = dbmToBars(strongest.dbm),
                    qualityLabel = dbmToQualityLabel(strongest.dbm),
                    isRegisteredSim = sorted.any { it.isRegistered },
                    towers = sorted
                )
            }
            .sortedByDescending { it.bestDbm }
    }

    private fun sanitizeDbm(rawDbm: Int): Int? {
        if (rawDbm == CellInfo.UNAVAILABLE || rawDbm > -20 || rawDbm < -150) return null
        return rawDbm
    }

    private fun formatMccMnc(mcc: String?, mnc: String?): String {
        val c = mcc?.takeIf { it.isNotBlank() } ?: "—"
        val n = mnc?.takeIf { it.isNotBlank() } ?: "—"
        return "$c-$n"
    }
}
